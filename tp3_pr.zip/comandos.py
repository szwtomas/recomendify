from modelos import *
from biblioteca import *
from grafo import *

'''
CAMINO MINIMO
'''
'''
Recibe el grafo de usuarios, la cancion en la cual empieza el camino, la cancion a la que se quiere llegar
y un diccionario con todas las playlists por id
'''
def camino_canciones_usuarios(grafo_usuarios, cancion_origen, cancion_destino):
    existe_origen = False
    existe_destino = False
    for v in grafo_usuarios.obtener_vertices():
        if not isinstance(v, Cancion): continue
        if v == cancion_origen: existe_origen = True
        if v == cancion_destino: existe_destino = True
    if not existe_destino or not existe_origen:
        print("Tanto el origen como el destino deben ser canciones")
        raise ValueError(("No existe la cancion"))
        return False, False
    camino = camino_minimo(grafo_usuarios, cancion_origen, cancion_destino)
    if not camino: 
        print("No se encontro recorrido")
        return False, False
    return True, camino
        
def imprimir_camino(camino, playlists):
    print(camino[0].obtener_nombre_cancion() + " - " + camino[0].obtener_artista(), end=" --> ")
    for i in range(1, len(camino) - 1):
        if isinstance(camino[i], Cancion): continue
        print("aparece en playlist", end=" --> ")
        print(playlists[(camino[i].obtener_playlist_cancion(camino[i-1], playlists), camino[i].obtener_nombre())].obtener_nombre(), end=" --> ")
        print("de", end=" --> ")
        print(camino[i].obtener_nombre(), end=" --> ")
        print("tiene una playlist", end = " --> ")
        print(playlists[(camino[i].obtener_playlist_cancion(camino[i+1], playlists), camino[i].obtener_nombre())].obtener_nombre(), end=" --> ")
        print("donde aparece", end=" --> ")
        if i != (len(camino) - 2): print(camino[i+1].obtener_nombre_cancion() + " - " + camino[i+1].obtener_artista(), end=" --> ")
        else: print(camino[i+1].obtener_nombre_cancion() + " - " + camino[i+1].obtener_artista())


def comando_camino(grafo_completo, playlists, linea):
    str_canciones = linea[7:-1]
    canciones = str_canciones.split(' >>>> ')
    if len(canciones) != 2:
        print("Se deben ingresar 2 canciones")
        return
    cancion_leida = canciones[0].split(' - ')
    if len(cancion_leida) != 2: 
        print("Tanto el origen como el destino deben ser canciones")
        return
    cancion_origen = Cancion(cancion_leida[0], cancion_leida[1])
    cancion_leida = canciones[1].split(' - ')
    if len(cancion_leida) != 2: 
        print("Tanto el origen como el destino deben ser canciones")
        return
    cancion_destino = Cancion(cancion_leida[0], cancion_leida[1]) 
    existe_camino, camino = camino_canciones_usuarios(grafo_completo, cancion_origen, cancion_destino)
    if existe_camino: 
        imprimir_camino(camino, playlists)


    