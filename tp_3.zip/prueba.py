

dic = {}
dic[("a", 2)] = 4

print(("a", 2) in dic)