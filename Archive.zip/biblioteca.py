from cola import Cola
from modelos import *

ITERACIONES_DEFECTO = 6
AMORTIGUACION_DEFECTO = 0.85

'''
Recibe un grafo con canciones, el coeficiente de amortiguacion a usar y un diccionario con los rankings
Devuelve el ranking de la presente iteracion de la cancion
'''
def ranking_cancion(grafo, coeficiente_amortiguacion, cancion, rankings):
    termino_amortiguacion = (1 - coeficiente_amortiguacion) / grafo.cantidad_vertices()
    termino_ranking = 0
    for ady in grafo.obtener_adyacentes(cancion):
        termino_ranking += rankings[ady] / len(grafo.obtener_adyacentes(ady))
    return termino_amortiguacion + coeficiente_amortiguacion * termino_ranking

'''
Recibe un grafo de canciones, la cantidad de iteraciones a realizar (mientras mas se hagan es mas preciso, se toma
500 como valor por defecto), y el coeficiente de amortiguacion a usar.
Devuelve una lista ordenada con las canciones rankeadas, en forma de tupla (pagerank, cancion)
'''
def page_rank_canciones(grafo, iteraciones = ITERACIONES_DEFECTO, coeficiente_amortiguacion = AMORTIGUACION_DEFECTO):
    rankings = {}
    for cancion in grafo.obtener_vertices():
        rankings[cancion] = 1 / grafo.cantidad_vertices()
    for i in range(iteraciones):
        for cancion in grafo.obtener_vertices(): 
            rankings[cancion] = ranking_cancion(grafo, coeficiente_amortiguacion, cancion, rankings)
    lista_rankings = []
    for cancion in rankings:
        lista_rankings.append((rankings[cancion], cancion))
    lista_rankings.sort(key = lambda tupla: tupla[0])
    lista_rankings.reverse()
    return lista_rankings



'''
Recibe un diccionario con padres, y el destino final del camino
Devuelve una lista con el camino reeconstruido
'''
def reecontrstruir_camino(padres, destino):
    v = destino
    camino = []
    while v is not None:
        camino.append(v)
        v = padres[v]
    camino.reverse()
    return camino

'''
Recibe un grafo con canciones y usuarios, la cancion de origen y donde se quiere llegar
Devuelve una lista con el camino minimo entre las dos canciones
'''
def camino_minimo(grafo, cancion_origen, cancion_destino):
    visitados = set()
    visitados.add(cancion_origen)
    padres = {}
    padres[cancion_origen] = None
    cola = Cola()
    cola.encolar(cancion_origen)
    while not cola.esta_vacia():
        v = cola.desencolar()
        for w in grafo.obtener_adyacentes(v):
            if w not in visitados:
                visitados.add(w)
                padres[w] = v
                cola.encolar(w)
                if isinstance(w, Cancion) and w == cancion_destino:
                    return reecontrstruir_camino(padres, cancion_destino)
    return False


def _ciclo_n_canciones(grafo_canciones, n, cancion_origen, cancion_actual, visitados, camino):
    visitados.add(cancion_actual)
    camino.append(cancion_actual)
    if len(camino) == n:
        for w in grafo_canciones.obtener_adyacentes(cancion_actual):
            if w == cancion_origen:
                camino.append(w)
                return True
        camino.pop()
        visitados.remove(cancion_actual)
        return False
    for w in grafo_canciones.obtener_adyacentes(cancion_actual):
        if w not in visitados:
            if _ciclo_n_canciones(grafo_canciones, n, cancion_origen, w, visitados, camino): return True
    visitados.remove(cancion_actual)
    camino.pop()
    return False

'''
Recibe un grafo con canciones, la cancion donde se quiere comenzar y un numero n
Devuelve una lista con un camino que sea un ciclo de exactamente n canciones
'''
def ciclo_n_canciones(grafo_canciones, n, cancion_origen):
    camino = []
    visitados = set()
    if _ciclo_n_canciones(grafo_canciones, n, cancion_origen, cancion_origen, visitados, camino): return camino
    return False


'''
Recibe un grafo con canciones, un numero n y la cancion de origen
Devuelve la cantidad de canciones que estan a un rango n de la misma
'''
def canciones_en_rango(grafo_canciones, n, cancion_origen):
    visitados = set()
    dist = {}
    dist[cancion_origen] = 0
    visitados.add(cancion_origen)
    cola = Cola()
    cola.encolar(cancion_origen)
    cant_en_rango = 0
    while not cola.esta_vacia():
        c = cola.desencolar()
        for w in grafo_canciones.obtener_adyacentes(c):
            if w not in visitados:
                visitados.add(w)
                dist[w] = dist[c] + 1
                if dist[w] > n: break
                if dist[w] == n: cant_en_rango += 1
                cola.encolar(w) 
    return cant_en_rango
    
'''
Recibe un grafo no dirigo, devuelve un diccionario con los grados de los vertices
'''
def obtener_grados(grafo):
    grados = {}
    for v in grafo.obtener_vertices():
        grados[v] = 0
    for v in grafo.obtener_vertices():
        grados[v] = len(grafo.obtener_adyacentes(v))
    return grados
'''
#Devuelve la cantidad de adyacentes de v que estan relacionados con v
def cantidad_relacionados(grafo, v):
    cant_relacionados = 0
    for w in grafo.obtener_adyacentes(v):
        for k in grafo.obtener_adyacentes(w):
            if grafo.existe_arista(v, k): cant_relacionados += 1
    return cant_relacionados
'''
def cantidad_relacionados(grafo, v):
    cant_relacionados = 0
    aristas_contadas = set()
    for w in grafo.obtener_adyacentes(v):
        for k in grafo.obtener_adyacentes(v):
            if grafo.existe_arista(w, k) and (k, w) not in aristas_contadas:
                cant_relacionados += 1
                aristas_contadas.add((w, k))
    return cant_relacionados 

CANT_DECIMALES = 3

def clustering_cancion(grafo, grados, cancion):
    if grados[cancion] == 0: return 0
    return round(2 * ((cantidad_relacionados(grafo, cancion))) / (grados[cancion] * (grados[cancion] - 1)), CANT_DECIMALES)


def clustering_promedio(grafo, grados):
    suma = 0
    for v in grafo.obtener_vertices():
        suma += clustering_cancion(grafo, grados, v)
    return suma / grafo.cantidad_vertices()


def actualizar_page_rank(grafo, v, grados, page_rank):
    LARGO_CAMINO = 30
    if v not in page_rank: page_rank[v] = 0
    for i in range(LARGO_CAMINO):
        if i == 0: valor_transmitido = 1 / grados[v]
        else: valor_transmitido = page_rank[v] / grados[v]
        v = grafo.adyacente_aleatorio(v)
        if v not in page_rank: page_rank[v] = 0
        page_rank[v] += valor_transmitido
    return page_rank


#Recibe el grafo, una lista con gustos del usuario, la cantidad de recomendaciones a recibir, y si se quieren canciones o users
def recomendar(grafo, lista_gustos, n, grados, rec_canciones = True):
    CANT_ITERACIONES = 300
    page_rank = {}
    recomendaciones = []
    for i in range(CANT_ITERACIONES):
        for gusto in lista_gustos:
            actualizar_page_rank(grafo, gusto, grados, page_rank)  
    entradas_rankeadas = []
    for key in page_rank:
        if rec_canciones and isinstance(key, Cancion): #Si quiero canciones y la entrada es una cancion
            if key not in lista_gustos: entradas_rankeadas.append((page_rank[key], key))
        elif (not rec_canciones) and isinstance(key, Usuario): #Si quiero usuarios y la entrada es un usuario
            if key not in lista_gustos: entradas_rankeadas.append((page[key], key))
    entradas_rankeadas.sort(key = lambda tupla: tupla[0])
    entradas_rankeadas.reverse()
    print(len(entradas_rankeadas))
    for i in range(n):
        recomendaciones.append((entradas_rankeadas[i])[1])
    return recomendaciones
